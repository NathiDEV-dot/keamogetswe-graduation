import fs from 'node:fs';
import path from 'node:path';
const dir='pages-dist';let html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
html=html.replace(/<script type="module" crossorigin src="([^"]+)"><\/script>/,(_all,file)=>'<script type="module">'+fs.readFileSync(path.join(dir,file),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
html=html.replace(/<link rel="stylesheet" crossorigin href="([^"]+)">/,(_all,file)=>'<style>'+fs.readFileSync(path.join(dir,file),'utf8')+'</style>');
fs.mkdirSync('github-publish',{recursive:true});fs.writeFileSync('github-publish/index.html',html);
if(html.includes('/api/memories')||html.includes('/api/photos/'))throw Error('Unexpected server API dependency');
console.log('Pages bundle ready: '+Buffer.byteLength(html)+' bytes. No server API dependency.');
