import React from 'react';
import {createRoot} from 'react-dom/client';
import Home from './App';
import '../app/globals.css';
createRoot(document.getElementById('root')!).render(<Home/>);
