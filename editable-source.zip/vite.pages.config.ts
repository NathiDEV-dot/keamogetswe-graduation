import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
export default defineConfig({
 root: 'github-pages', base: './', plugins: [react()],
 css: {postcss: {plugins: [tailwindcss()]}},
 build: {assetsInlineLimit: 1000000, outDir: '../pages-dist',emptyOutDir:true},
});
